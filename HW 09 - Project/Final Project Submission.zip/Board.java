/**
 * Name: Jerry Cai
 * Pennkey: jycai
 * Execution: java Board
 *
 * Description: Board object creates array
**/
public class Board {
    
    public Cell[][] cellArray;
    public int[][] intArray;
    
    public Board() {
        cellArray = new Cell[9][9];
        intArray = new int[9][9];
    }
    
}
