/**
 * Name: TODO
 * Pennkey: TODO
 * Execution: TODO
 *
 * Description: TODO
**/
// public class BombCellDraft {

//     public int value;
//     public int xPos;
//     public int yPos;

//     //Interface Implementation

//     public void PlaceCellsOnBoard() {
//     }

//     //Constructor

//     public BombCell(int v, int x, int y) {
//         value = v;
//         xPos = x;
//         yPos = y;
//     }

//     public BombCell (Point position) {
//     }

//     public void draw() {
//     }

//     public void reactToClick() {
//     }
// }
