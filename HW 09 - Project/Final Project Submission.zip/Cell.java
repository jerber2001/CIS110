/**
 * Name: Jerry Cai
 * Pennkey: jycai
 * Execution: java Cell
 *
 * Description: Cell Interface
**/
public interface Cell {
    
    /**
     * Inputs: None
     * Outputs: None
     * Description: Getter function for X value
    */
    public int getX();
    /**
     * Inputs: None
     * Outputs: None
     * Description: Getter function for Y value
    */
    public int getY();
    /**
     * Inputs: None
     * Outputs: integer
     * Description: get value attribute
    */
    public int getValue();
    
    /**
     * Inputs: Integer
     * Outputs: None
     * Description: Sets X value
    */
    public void setX(int x);
    /**
     * Inputs: Integer
     * Outputs: None
     * Description: Sets Y value
    */
    public void setY(int x);
    /**
     * Inputs: int value
     * Outputs:
     * Description: sets the value
    */
    public void setValue(int v);
    /**
     * Inputs: None
     * Outputs: None
     * Description: Boolean for revealled cell
    */
    public void setRevealed();
    /**
     * Inputs: None
     * Outputs: Boolean
     * Description: boolean of whether the cell is revealed
    */
    public boolean returnRevealed();
    

}
