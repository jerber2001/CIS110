public interface Cell {
    
//     public int value = 0;
    
//     public void draw();
//     public void reactToClick();

    public void PlaceCellsOnBoard();

    public int getX();
    public int getY();
    public int getValue();
    public void setX(int x);
    public void setY(int x);
    public void setValue(int v);
    
    
//     public void d
}