public class Board {
    
    public Cell[][] cellArray;
    public int[][] intArray;
    
    public Board() {
        cellArray = new Cell[9][9];
        intArray = new int[9][9];
    }
    
    
    
    
  
    //Creates 
    
    
}