// public class BoardDraft {
    
//     public static void main(String[] args) {
//         Board test = new Board();
//         test.drawGrid();
//     }
    
//     public NumberCell[][] cellArray;
//     public int[][] intArray;
    
//     public Board() {
//         cellArray = new NumberCell[9][9];
//         intArray = new int[9][9];
//     }
    
    
    
//     public void drawGrid() {
//         PennDraw.picture(0.5, 0.5, "grid.png");
        
//         for (int i = 0; i < 9; i++) {
//             for (int j = 0; j < 9; j++) {
//                 cellArray[i][j] = new NumberCell(0, j, 8 - i);
//                 System.out.println(cellArray[i][j].value);
// //                 intArray[i][j] = 0;
//             }
//         }
//     }
  
//     //Creates 
    
// }