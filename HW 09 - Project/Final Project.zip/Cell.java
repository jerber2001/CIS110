/**
 * Name: Jerry Cai
 * Pennkey: jycai
 * Execution: java Cell
 *
 * Description: Cell Interface
**/
public interface Cell {
    
    /**
     * Inputs: None
     * Outputs: None
     * Description: Getter function for X value
    */
    int getX();
    /**
     * Inputs: None
     * Outputs: None
     * Description: Getter function for Y value
    */
    int getY();
    /**
     * Inputs: None
     * Outputs: integer
     * Description: get value attribute
    */
    int getValue();
    
    /**
     * Inputs: Integer
     * Outputs: None
     * Description: Sets X value
    */
    void setX(int x);
    /**
     * Inputs: Integer
     * Outputs: None
     * Description: Sets Y value
    */
    void setY(int x);
    /**
     * Inputs: int value
     * Outputs:
     * Description: sets the value
    */
    void setValue(int v);
    /**
     * Inputs: None
     * Outputs: None
     * Description: Boolean for revealled cell
    */
    void setRevealed();
    /**
     * Inputs: None
     * Outputs: Boolean
     * Description: boolean of whether the cell is revealed
    */
    boolean returnRevealed();
    

}
