/**
 * Name: TODO
 * Pennkey: TODO
 * Execution: TODO
 *
 * Description: TODO
**/
// public class NumberCellDraft {

//     public int value;
//     public int xPos;
//     public int yPos;

//     public void PlaceCellsOnBoard() {
//     }
//     public NumberCell(int v, int x, int y) {
//         value = v;
//         xPos = x;
//         yPos = y;
//     }

//     public void draw() {
//     }

//     public void reactToClick() {
//     }
// }
